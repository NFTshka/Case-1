
CREATE DATABASE TourismDB;
GO
USE TourismDB;
GO

CREATE TABLE Users (
    user_id INT PRIMARY KEY IDENTITY,
    username NVARCHAR(50),
    email NVARCHAR(100),
    created_at DATETIME DEFAULT GETDATE()
);
