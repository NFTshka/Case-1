
# Delphi Web-приложение (Delphi + IIS + MS SQL Server)

## Описание
Простое ISAPI Web-приложение на Delphi 10.2 с подключением к MS SQL Server. Развёртывается через IIS.

## Используемые технологии
- Delphi 10.2 Tokyo (ISAPI DLL)
- IIS (Web-сервер)
- MS SQL Server

## Как запустить
1. Соберите проект в Delphi как ISAPI DLL.
2. Настройте IIS для запуска `.dll`-модуля.
3. Создайте базу `TourismDB` и импортируйте `schema.sql`.
